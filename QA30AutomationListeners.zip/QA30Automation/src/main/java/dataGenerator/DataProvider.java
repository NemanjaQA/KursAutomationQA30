package dataGenerator;public class DataProvider {
}
