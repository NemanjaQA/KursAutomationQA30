package tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

public class FailedLoginTest extends BaseTest{


    @Test
    public void failedLogin() {

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login("emailQA30@code.qa", "123456789");
        try {
            loginPage.verifyFailedLogin("There is 1 error\nAuthentication failed");
            System.out.println("Test passed: user is not logged in");
        } catch (Exception e) {
            Assert.fail("Something went wrong");
        }
    }
}
