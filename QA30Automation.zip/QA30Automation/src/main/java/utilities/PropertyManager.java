package utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyManager {

    private static String driverPath;
    public static PropertyManager getInstance(){
        PropertyManager instance = new PropertyManager();
        Properties properties = new Properties();

        try {
            FileInputStream fi = new FileInputStream("src/main/resources/configuration.properties");
            properties.load(fi);
        }catch (Exception e){
            e.printStackTrace();
        }
        driverPath = properties.getProperty("driverPath");

        return instance;
    }

    public String getDriverPath() {
        return driverPath;
    }
    public static String getDriverPath2() {
        return driverPath;
    }
}
